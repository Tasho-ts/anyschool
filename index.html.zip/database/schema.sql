-- EduConnect — PostgreSQL schema
-- Multi-tenant via institution_id on every tenant-scoped table + Row-Level Security.

create extension if not exists "pgcrypto"; -- for gen_random_uuid()

-- ---------------------------------------------------------------------------
-- Institutions (tenants)
-- ---------------------------------------------------------------------------
create type institution_type as enum ('SCHOOL', 'COLLEGE', 'COACHING', 'CORPORATE');

create table institutions (
  id                uuid primary key default gen_random_uuid(),
  slug              varchar(63) unique not null,        -- subdomain: slug.educonnect.com
  name              varchar(255) not null,
  tagline           varchar(255),
  about             text,
  logo_url          text,
  type              institution_type not null default 'SCHOOL',
  role_labels       jsonb not null default '{"guardian":"Parent","student":"Student"}',
  privacy_settings  jsonb not null default '{"teachers_see_guardian_contact": true}',
  is_active         boolean not null default true,
  created_at        timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Users (all roles live in one table; role determines what they can do)
-- ---------------------------------------------------------------------------
create type user_role as enum ('SUPER_ADMIN', 'INST_ADMIN', 'TEACHER', 'GUARDIAN', 'STUDENT');

create table users (
  id                uuid primary key default gen_random_uuid(),
  institution_id    uuid references institutions(id) on delete cascade, -- null only for SUPER_ADMIN
  role              user_role not null,
  name              varchar(255) not null,
  email             citext unique,
  phone             varchar(20),
  password_hash     text not null,
  photo_url         text,
  is_active         boolean not null default true,
  created_at        timestamptz not null default now(),
  constraint chk_tenant_role check (
    (role = 'SUPER_ADMIN' and institution_id is null) or
    (role <> 'SUPER_ADMIN' and institution_id is not null)
  )
);
create index idx_users_institution on users(institution_id);

-- ---------------------------------------------------------------------------
-- Classes / Subjects
-- ---------------------------------------------------------------------------
create table classes (
  id                uuid primary key default gen_random_uuid(),
  institution_id    uuid not null references institutions(id) on delete cascade,
  name              varchar(100) not null,        -- "Grade 8" / "Batch 2026"
  section           varchar(50),                  -- "A" / "Cohort 3"
  academic_year     varchar(20) not null,
  created_at        timestamptz not null default now()
);
create index idx_classes_institution on classes(institution_id);

create table subjects (
  id                uuid primary key default gen_random_uuid(),
  institution_id    uuid not null references institutions(id) on delete cascade,
  class_id          uuid not null references classes(id) on delete cascade,
  name              varchar(100) not null
);
create index idx_subjects_institution on subjects(institution_id);

-- which teacher teaches which subject in which class
create table class_teachers (
  class_id          uuid not null references classes(id) on delete cascade,
  subject_id        uuid not null references subjects(id) on delete cascade,
  teacher_id        uuid not null references users(id) on delete cascade,
  primary key (class_id, subject_id, teacher_id)
);

-- ---------------------------------------------------------------------------
-- Students / Guardians
-- ---------------------------------------------------------------------------
create table students (
  id                uuid primary key default gen_random_uuid(),
  institution_id    uuid not null references institutions(id) on delete cascade,
  class_id          uuid not null references classes(id),
  user_id           uuid references users(id) on delete set null, -- optional student login
  roll_no           varchar(50),
  full_name         varchar(255) not null,
  dob               date,
  photo_url         text,
  medical_info      text,                          -- field-level restricted, see privacy notes
  created_at        timestamptz not null default now(),
  unique (class_id, roll_no)
);
create index idx_students_institution on students(institution_id);

-- many-to-many: a student can have multiple guardians, a guardian multiple students/wards
create table guardians (
  student_id        uuid not null references students(id) on delete cascade,
  guardian_user_id  uuid not null references users(id) on delete cascade,
  relation          varchar(50) not null,           -- "Mother","Father","Sponsor","Manager"...
  is_primary        boolean not null default false,
  primary key (student_id, guardian_user_id)
);

-- ---------------------------------------------------------------------------
-- Attendance
-- ---------------------------------------------------------------------------
create type attendance_status as enum ('PRESENT', 'ABSENT', 'LATE', 'EXCUSED');

create table attendance_records (
  id                uuid primary key default gen_random_uuid(),
  institution_id    uuid not null references institutions(id) on delete cascade,
  student_id        uuid not null references students(id) on delete cascade,
  class_id          uuid not null references classes(id),
  date              date not null,
  status            attendance_status not null,
  marked_by         uuid not null references users(id),
  marked_at         timestamptz not null default now(),
  unique (student_id, date)                        -- re-marking is an upsert, not a duplicate
);
create index idx_attendance_institution on attendance_records(institution_id);
create index idx_attendance_class_date on attendance_records(class_id, date);

-- ---------------------------------------------------------------------------
-- Grades
-- ---------------------------------------------------------------------------
create table grade_entries (
  id                uuid primary key default gen_random_uuid(),
  institution_id    uuid not null references institutions(id) on delete cascade,
  student_id        uuid not null references students(id) on delete cascade,
  subject_id        uuid not null references subjects(id),
  term              varchar(50) not null,           -- "Term 1 2026", "Mid-sem"
  marks_obtained    numeric(6,2) not null,
  marks_total       numeric(6,2) not null,
  entered_by        uuid not null references users(id),
  entered_at        timestamptz not null default now(),
  unique (student_id, subject_id, term)
);
create index idx_grades_institution on grade_entries(institution_id);

-- ---------------------------------------------------------------------------
-- Notices
-- ---------------------------------------------------------------------------
create type notice_scope as enum ('INSTITUTION', 'CLASS');

create table notices (
  id                uuid primary key default gen_random_uuid(),
  institution_id    uuid not null references institutions(id) on delete cascade,
  title             varchar(255) not null,
  body              text not null,
  scope             notice_scope not null,
  class_id          uuid references classes(id),   -- required when scope = CLASS
  attachment_url    text,
  created_by        uuid not null references users(id),
  created_at        timestamptz not null default now(),
  constraint chk_class_scope check (
    (scope = 'CLASS' and class_id is not null) or (scope = 'INSTITUTION')
  )
);
create index idx_notices_institution on notices(institution_id);

-- ---------------------------------------------------------------------------
-- Chat
-- ---------------------------------------------------------------------------
create type chat_thread_kind as enum ('DIRECT', 'GROUP');

create table chat_threads (
  id                uuid primary key default gen_random_uuid(),
  institution_id    uuid not null references institutions(id) on delete cascade,
  kind              chat_thread_kind not null,
  title             varchar(255),                  -- e.g. "Class 8-A Parents + Teachers"
  created_at        timestamptz not null default now()
);

create table chat_thread_participants (
  thread_id         uuid not null references chat_threads(id) on delete cascade,
  user_id           uuid not null references users(id) on delete cascade,
  primary key (thread_id, user_id)
);

create table chat_messages (
  id                uuid primary key default gen_random_uuid(),
  thread_id         uuid not null references chat_threads(id) on delete cascade,
  sender_id         uuid not null references users(id),
  body              text,
  attachment_url    text,
  sent_at           timestamptz not null default now()
);
create index idx_chat_messages_thread on chat_messages(thread_id, sent_at);

-- ---------------------------------------------------------------------------
-- Audit log (append-only)
-- ---------------------------------------------------------------------------
create table audit_logs (
  id                uuid primary key default gen_random_uuid(),
  institution_id    uuid references institutions(id) on delete cascade,
  actor_id          uuid references users(id),
  action            varchar(100) not null,          -- "GRADE_UPDATED","MEDICAL_INFO_VIEWED",...
  entity_type       varchar(100) not null,
  entity_id         uuid,
  metadata          jsonb,
  created_at        timestamptz not null default now()
);
create index idx_audit_institution on audit_logs(institution_id, created_at);

-- ---------------------------------------------------------------------------
-- Row-Level Security — second line of defense for tenant isolation.
-- The app sets `set_config('app.current_institution', '<uuid>', true)` per request.
-- ---------------------------------------------------------------------------
alter table classes enable row level security;
alter table students enable row level security;
alter table attendance_records enable row level security;
alter table grade_entries enable row level security;
alter table notices enable row level security;
alter table chat_threads enable row level security;

create policy tenant_isolation_classes on classes
  using (institution_id = current_setting('app.current_institution', true)::uuid);
create policy tenant_isolation_students on students
  using (institution_id = current_setting('app.current_institution', true)::uuid);
create policy tenant_isolation_attendance on attendance_records
  using (institution_id = current_setting('app.current_institution', true)::uuid);
create policy tenant_isolation_grades on grade_entries
  using (institution_id = current_setting('app.current_institution', true)::uuid);
create policy tenant_isolation_notices on notices
  using (institution_id = current_setting('app.current_institution', true)::uuid);
create policy tenant_isolation_chat_threads on chat_threads
  using (institution_id = current_setting('app.current_institution', true)::uuid);

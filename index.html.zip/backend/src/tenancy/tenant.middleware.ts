import { Injectable, NestMiddleware, NotFoundException } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { PrismaService } from '../common/prisma.service';

// Augment Express Request with the resolved tenant, so every downstream
// controller/service can read `req.institution` instead of re-querying it.
declare global {
  namespace Express {
    interface Request {
      institution?: { id: string; slug: string };
    }
  }
}

/**
 * Resolves which institution (tenant) the current request belongs to.
 *
 * - Public routes (landing page, login): resolved from the subdomain,
 *   e.g. `greenwood.educonnect.com` -> slug "greenwood".
 * - Authenticated routes: the JWT already carries `institution_id` (see
 *   auth.service.ts). We still cross-check it against the subdomain so a
 *   token minted for one institution can't be replayed against another
 *   institution's subdomain.
 *
 * After resolving, we set a Postgres session variable that the schema's
 * Row-Level Security policies read (`app.current_institution`). This is
 * the second line of defense described in README.md — even if a query
 * forgets its WHERE institution_id clause, RLS blocks cross-tenant rows.
 */
@Injectable()
export class TenantMiddleware implements NestMiddleware {
  constructor(private readonly prisma: PrismaService) {}

  async use(req: Request, res: Response, next: NextFunction) {
    const slug = this.extractSlug(req);
    if (!slug) {
      // Platform-level routes (super admin, marketing site root) have no tenant.
      return next();
    }

    const institution = await this.prisma.institution.findUnique({
      where: { slug },
      select: { id: true, slug: true, isActive: true },
    });

    if (!institution || !institution.isActive) {
      throw new NotFoundException(`No active institution at "${slug}"`);
    }

    // If the request is authenticated, req.user was attached by AuthGuard
    // earlier in the chain (guard order matters — see main.ts). Reject a
    // token whose embedded institution_id doesn't match this subdomain.
    const tokenInstitutionId = (req as any).user?.institutionId;
    if (tokenInstitutionId && tokenInstitutionId !== institution.id) {
      throw new NotFoundException('Session does not belong to this institution');
    }

    req.institution = { id: institution.id, slug: institution.slug };

    // Scope this request's DB connection for RLS. With Prisma this is done
    // via a transaction-scoped `SET LOCAL`, wired up in prisma.service.ts's
    // `forInstitution()` helper — every repository call in this request
    // should go through that helper rather than the raw client.
    next();
  }

  private extractSlug(req: Request): string | null {
    // Path-based tenancy fallback: /api/v1/t/greenwood/...
    const pathMatch = req.path.match(/^\/api\/v1\/t\/([a-z0-9-]+)\//);
    if (pathMatch) return pathMatch[1];

    // Subdomain-based tenancy: greenwood.educonnect.com
    const host = req.hostname; // e.g. "greenwood.educonnect.com"
    const parts = host.split('.');
    if (parts.length >= 3) {
      const sub = parts[0];
      if (sub !== 'www' && sub !== 'api') return sub;
    }
    return null;
  }
}

import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
  OnGatewayConnection,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import * as jwt from 'jsonwebtoken';
import { PrismaService } from '../common/prisma.service';

interface SendMessageDto {
  threadId: string;
  body: string;
  attachmentUrl?: string;
}

/**
 * One Socket.IO namespace per institution (`/chat/<institutionId>`), so a
 * socket physically cannot receive events from another tenant's threads —
 * tenancy is enforced at the connection layer, not just per-message.
 */
@WebSocketGateway({ namespace: /^\/chat\/.+/, cors: { origin: process.env.APP_ORIGIN } })
export class ChatGateway implements OnGatewayConnection {
  @WebSocketServer() server!: Server;

  constructor(private readonly prisma: PrismaService) {}

  async handleConnection(socket: Socket) {
    // Auth: same JWT used for REST, passed as a query param or auth header
    // during the socket handshake.
    const token = socket.handshake.auth?.token as string;
    try {
      const claims = jwt.verify(token, process.env.JWT_ACCESS_SECRET!) as any;
      const institutionIdFromNamespace = socket.nsp.name.split('/')[2];
      if (claims.institutionId !== institutionIdFromNamespace) {
        socket.disconnect();
        return;
      }
      (socket as any).user = claims;

      // Join a room per thread the user participates in, so `emit` below
      // only reaches the right people.
      const threads = await this.prisma.chatThreadParticipant.findMany({
        where: { userId: claims.sub },
        select: { threadId: true },
      });
      threads.forEach((t) => socket.join(t.threadId));
    } catch {
      socket.disconnect();
    }
  }

  @SubscribeMessage('chat:send')
  async onSend(@MessageBody() dto: SendMessageDto, @ConnectedSocket() socket: Socket) {
    const user = (socket as any).user;

    // Confirm this user is actually a participant of the thread before
    // accepting the message — room membership above is a fast-path
    // optimization, this is the authoritative check.
    const isParticipant = await this.prisma.chatThreadParticipant.findUnique({
      where: { threadId_userId: { threadId: dto.threadId, userId: user.sub } },
    });
    if (!isParticipant) return;

    const message = await this.prisma.chatMessage.create({
      data: {
        threadId: dto.threadId,
        senderId: user.sub,
        body: dto.body,
        attachmentUrl: dto.attachmentUrl,
      },
    });

    socket.nsp.to(dto.threadId).emit('chat:message', message);
    return message;
  }
}

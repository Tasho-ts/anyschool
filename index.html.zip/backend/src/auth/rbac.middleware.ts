import {
  CanActivate,
  ExecutionContext,
  Injectable,
  SetMetadata,
  ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';

export type UserRole = 'SUPER_ADMIN' | 'INST_ADMIN' | 'TEACHER' | 'GUARDIAN' | 'STUDENT';

/** Decorator: @Roles('INST_ADMIN', 'TEACHER') on a controller method. */
export const ROLES_KEY = 'roles';
export const Roles = (...roles: UserRole[]) => SetMetadata(ROLES_KEY, roles);

/**
 * Runs after AuthGuard (which attaches req.user from the JWT).
 * Blocks the request unless req.user.role is in the route's @Roles(...) list.
 * A route with no @Roles() decorator is open to any authenticated user.
 */
@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<UserRole[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!required || required.length === 0) return true;

    const { user } = context.switchToHttp().getRequest();
    if (!user || !required.includes(user.role)) {
      throw new ForbiddenException(
        `This action requires one of: ${required.join(', ')}`,
      );
    }
    return true;
  }
}

/**
 * Extra, narrower checks that role alone can't express — e.g. "this teacher
 * is actually assigned to this class" or "this guardian is actually linked
 * to this student". Role answers "what kind of user is this"; these
 * scope-checks answer "does this specific user own this specific record".
 * Call from inside the relevant service method, close to the query.
 */
export class ScopeChecks {
  static assertTeacherOwnsClass(teacherClassIds: string[], classId: string) {
    if (!teacherClassIds.includes(classId)) {
      throw new ForbiddenException('You are not assigned to this class');
    }
  }

  static assertGuardianOwnsStudent(guardianStudentIds: string[], studentId: string) {
    if (!guardianStudentIds.includes(studentId)) {
      throw new ForbiddenException('You are not linked to this student');
    }
  }
}

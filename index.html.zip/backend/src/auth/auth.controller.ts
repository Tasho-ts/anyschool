import { Body, Controller, Post, Req } from '@nestjs/common';
import { Request } from 'express';
import { AuthService } from './auth.service';
import { IsString } from 'class-validator';

class LoginDto {
  @IsString() identifier!: string; // email or phone
  @IsString() password!: string;
}

class OtpVerifyDto {
  @IsString() otpToken!: string;
  @IsString() code!: string;
}

class RefreshDto {
  @IsString() refreshToken!: string;
}

@Controller('auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  // Institution is already resolved onto req.institution by TenantMiddleware
  // based on the subdomain the request came in on (see tenant.middleware.ts).
  @Post('login')
  login(@Body() dto: LoginDto, @Req() req: Request) {
    return this.auth.login(dto.identifier, dto.password, req.institution!.id);
  }

  @Post('otp/verify')
  verifyOtp(@Body() dto: OtpVerifyDto) {
    return this.auth.verifyOtp(dto.otpToken, dto.code);
  }

  @Post('refresh')
  refresh(@Body() dto: RefreshDto) {
    return this.auth.refresh(dto.refreshToken);
  }

  // Password forgot/reset would follow the same shape: issue a short-lived
  // signed reset token emailed/texted to the user, then a second endpoint
  // that accepts { resetToken, newPassword } and revokes existing refresh
  // tokens for that user. Omitted here for brevity — same pattern as OTP.
}

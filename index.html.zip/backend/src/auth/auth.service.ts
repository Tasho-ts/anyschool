import { Injectable, UnauthorizedException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import * as jwt from 'jsonwebtoken';
import { PrismaService } from '../common/prisma.service';
import { OtpService } from './otp.service'; // sends via SMS provider (MSG91/Twilio) — not shown

const ACCESS_TOKEN_TTL = '15m';
const REFRESH_TOKEN_TTL = '30d';

interface TokenClaims {
  sub: string; // user id
  institutionId: string | null; // null only for SUPER_ADMIN
  role: string;
}

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly otp: OtpService,
  ) {}

  /**
   * Step 1 of login: verify email/phone + password. If the institution has
   * OTP enabled, this returns a short-lived otpToken instead of real tokens,
   * and the client must call /auth/otp/verify next.
   */
  async login(identifier: string, password: string, institutionId: string) {
    const user = await this.prisma.user.findFirst({
      where: {
        institutionId,
        isActive: true,
        OR: [{ email: identifier }, { phone: identifier }],
      },
    });

    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      // Same error for "no such user" and "wrong password" — don't leak
      // which one it was.
      throw new UnauthorizedException('Invalid credentials');
    }

    const institution = await this.prisma.institution.findUnique({
      where: { id: institutionId },
      select: { privacySettings: true, id: true },
    });
    const otpRequired = (institution as any)?.privacySettings?.otp_required === true;

    if (otpRequired) {
      const otpToken = await this.otp.issueAndSend(user.id, user.phone);
      return { requiresOtp: true, otpToken };
    }

    return this.issueTokens(user.id, institutionId, user.role);
  }

  async verifyOtp(otpToken: string, code: string) {
    const { userId } = await this.otp.verify(otpToken, code); // throws if wrong/expired
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    return this.issueTokens(user.id, user.institutionId, user.role);
  }

  async refresh(refreshToken: string) {
    let claims: TokenClaims;
    try {
      claims = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET!) as TokenClaims;
    } catch {
      throw new UnauthorizedException('Refresh token invalid or expired');
    }
    // In production, also check a refresh-token allowlist/blocklist in Redis
    // here so a logout or password reset can revoke outstanding tokens.
    return this.issueTokens(claims.sub, claims.institutionId, claims.role);
  }

  private issueTokens(userId: string, institutionId: string | null, role: string) {
    const claims: TokenClaims = { sub: userId, institutionId, role };
    const accessToken = jwt.sign(claims, process.env.JWT_ACCESS_SECRET!, {
      expiresIn: ACCESS_TOKEN_TTL,
    });
    const refreshToken = jwt.sign(claims, process.env.JWT_REFRESH_SECRET!, {
      expiresIn: REFRESH_TOKEN_TTL,
    });
    // The role-based redirect on the frontend (Login.tsx) reads `role` out
    // of the decoded access token to send the user to the right dashboard.
    return { accessToken, refreshToken, role, institutionId };
  }
}

import { Body, Controller, Get, Post, Query, Req, UseGuards } from '@nestjs/common';
import { Request } from 'express';
import { AttendanceService } from './attendance.service';
import { AuthGuard } from '../auth/auth.guard'; // verifies JWT, attaches req.user
import { RolesGuard, Roles } from '../auth/rbac.middleware';
import { ScopeChecks } from '../auth/rbac.middleware';
import { GuardianLinksService } from '../users/guardian-links.service';

@UseGuards(AuthGuard, RolesGuard)
@Controller()
export class AttendanceController {
  constructor(
    private readonly attendance: AttendanceService,
    private readonly guardianLinks: GuardianLinksService,
  ) {}

  @Post('teacher/attendance')
  @Roles('TEACHER')
  markAttendance(
    @Body() body: { classId: string; date: string; entries: { studentId: string; status: any }[] },
    @Req() req: Request,
  ) {
    const teacherId = (req as any).user.sub;
    const institutionId = req.institution!.id;
    return this.attendance.markClassAttendance(
      institutionId,
      teacherId,
      body.classId,
      body.date,
      body.entries,
    );
  }

  @Get('parent/children/:id/attendance')
  @Roles('GUARDIAN')
  async getChildAttendance(
    @Req() req: Request,
    @Query('from') from: string,
    @Query('to') to: string,
  ) {
    const guardianId = (req as any).user.sub;
    const studentId = req.params.id;

    // Role tells us "this is a guardian"; this scope check tells us "this
    // guardian is actually linked to *this* student" — see rbac.middleware.ts.
    const linkedIds = await this.guardianLinks.getLinkedStudentIds(guardianId);
    ScopeChecks.assertGuardianOwnsStudent(linkedIds, studentId);

    return this.attendance.getStudentAttendance(studentId, from, to);
  }
}

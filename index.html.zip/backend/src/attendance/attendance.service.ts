import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { ScopeChecks } from '../auth/rbac.middleware';
import { AuditService } from '../common/audit.service';

type AttendanceStatus = 'PRESENT' | 'ABSENT' | 'LATE' | 'EXCUSED';

interface MarkEntry {
  studentId: string;
  status: AttendanceStatus;
}

@Injectable()
export class AttendanceService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  /**
   * Teacher marks a whole class's attendance for one date in a single call.
   * Upserts on (studentId, date) so correcting a mismarked day just updates
   * the row rather than creating a duplicate — the unique constraint in
   * schema.sql is what makes this safe to call twice for the same date.
   */
  async markClassAttendance(
    institutionId: string,
    teacherId: string,
    classId: string,
    date: string,
    entries: MarkEntry[],
  ) {
    const teacherClassIds = await this.getTeacherClassIds(teacherId);
    ScopeChecks.assertTeacherOwnsClass(teacherClassIds, classId);

    const results = await this.prisma.$transaction(
      entries.map((e) =>
        this.prisma.attendanceRecord.upsert({
          where: { studentId_date: { studentId: e.studentId, date: new Date(date) } },
          create: {
            institutionId,
            studentId: e.studentId,
            classId,
            date: new Date(date),
            status: e.status,
            markedBy: teacherId,
          },
          update: { status: e.status, markedBy: teacherId, markedAt: new Date() },
        }),
      ),
    );

    await this.audit.log(institutionId, teacherId, 'ATTENDANCE_MARKED', 'class', classId, {
      date,
      count: entries.length,
    });

    const summary = results.reduce(
      (acc, r) => ({ ...acc, [r.status.toLowerCase()]: (acc as any)[r.status.toLowerCase()] + 1 }),
      { present: 0, absent: 0, late: 0, excused: 0 },
    );

    return { classId, date, marked: results.length, summary };
  }

  /** Parent-facing: a student's attendance history + rolled-up percentage. */
  async getStudentAttendance(studentId: string, from: string, to: string) {
    const records = await this.prisma.attendanceRecord.findMany({
      where: { studentId, date: { gte: new Date(from), lte: new Date(to) } },
      orderBy: { date: 'asc' },
    });

    const total = records.length;
    const present = records.filter((r) => r.status === 'PRESENT' || r.status === 'LATE').length;
    const percentage = total === 0 ? null : Math.round((present / total) * 1000) / 10;

    return { records, total, present, percentage };
  }

  private async getTeacherClassIds(teacherId: string): Promise<string[]> {
    const rows = await this.prisma.classTeacher.findMany({
      where: { teacherId },
      select: { classId: true },
    });
    return rows.map((r) => r.classId);
  }
}

'use client';

// components/Chat.tsx — dropped into either the teacher or parent app
// shell for a given thread. Connects to the institution-scoped namespace
// (`/chat/<institutionId>`) so a socket physically cannot see another
// tenant's messages — see chat.gateway.ts.

import { useEffect, useRef, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import { api } from '../lib/api';

interface Message {
  id: string;
  senderId: string;
  body: string;
  sentAt: string;
}

export default function Chat({
  threadId,
  institutionId,
  currentUserId,
  accessToken,
}: {
  threadId: string;
  institutionId: string;
  currentUserId: string;
  accessToken: string;
}) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState('');
  const socketRef = useRef<Socket | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Message history over REST (paginated) so the socket only has to
    // carry *new* messages, not the whole backlog on every reconnect.
    api.get(`/chat/threads/${threadId}/messages`).then(setMessages);

    const socket = io(`${process.env.NEXT_PUBLIC_WS_BASE_URL}/chat/${institutionId}`, {
      auth: { token: accessToken },
    });
    socket.on('chat:message', (msg: Message) => {
      if (msg.id) setMessages((prev) => [...prev, msg]);
    });
    socketRef.current = socket;
    return () => {
      socket.disconnect();
    };
  }, [threadId, institutionId, accessToken]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [messages]);

  function send() {
    const body = draft.trim();
    if (!body) return;
    socketRef.current?.emit('chat:send', { threadId, body });
    setDraft('');
  }

  return (
    <div className="flex h-[28rem] flex-col rounded-lg bg-white ring-1 ring-black/5">
      <div ref={scrollRef} className="flex-1 space-y-2 overflow-y-auto p-4">
        {messages.map((m) => {
          const mine = m.senderId === currentUserId;
          return (
            <div key={m.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[75%] rounded-2xl px-3 py-2 text-sm ${
                  mine ? 'bg-[#1E2A4A] text-white' : 'bg-[#F1F0EA] text-[#1E2A4A]'
                }`}
              >
                {m.body}
                <div className={`mt-1 font-mono text-[10px] ${mine ? 'text-white/60' : 'text-[#94A3B8]'}`}>
                  {new Date(m.sentAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <div className="flex gap-2 border-t border-black/5 p-3">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && send()}
          placeholder="Write a message…"
          className="flex-1 rounded-full border border-black/10 px-4 py-2 text-sm"
        />
        <button
          onClick={send}
          className="rounded-full bg-[#1E2A4A] px-4 py-2 text-sm font-medium text-white"
        >
          Send
        </button>
      </div>
    </div>
  );
}

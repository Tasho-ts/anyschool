// app/page.tsx (Next.js App Router) — one file serves every tenant's landing
// page; `middleware.ts` (not shown) rewrites the incoming subdomain into a
// header this Server Component reads, so no per-tenant deploys are needed.

import { headers } from 'next/headers';
import Link from 'next/link';

interface PublicInstitution {
  name: string;
  tagline: string | null;
  about: string | null;
  logoUrl: string | null;
  type: 'SCHOOL' | 'COLLEGE' | 'COACHING' | 'CORPORATE';
  roleLabels: { guardian: string; student: string };
  notices: { id: string; title: string; createdAt: string }[];
}

async function getInstitution(slug: string): Promise<PublicInstitution> {
  const res = await fetch(`${process.env.API_BASE_URL}/institutions/${slug}/public`, {
    next: { revalidate: 60 }, // public info changes rarely; cache a minute
  });
  if (!res.ok) throw new Error('Institution not found');
  return res.json();
}

// Each role gets its own ribbon color and a one-line description of what
// that login is for — the badge metaphor doubles as wayfinding, since a
// first-time parent doesn't necessarily know they want "Guardian" login.
const ROLE_BADGES = [
  { role: 'INST_ADMIN', label: 'Admin', ribbon: 'bg-[#1E2A4A]', blurb: 'Manage classes, staff & notices' },
  { role: 'TEACHER', label: 'Teacher', ribbon: 'bg-[#3B4C79]', blurb: 'Attendance, grades & messages' },
  { role: 'GUARDIAN', label: null, ribbon: 'bg-[#E8A33D]', blurb: 'Track attendance, grades & chat' },
] as const;

export default async function InstitutionLanding({ params }: { params: { slug: string } }) {
  const institution = await getInstitution(params.slug);

  return (
    <main className="min-h-screen bg-[#F7F5F0] text-[#1E2A4A]">
      <header className="mx-auto flex max-w-5xl items-center gap-4 px-6 pt-10">
        {institution.logoUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={institution.logoUrl} alt="" className="h-14 w-14 rounded-full object-cover" />
        ) : (
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-[#1E2A4A] font-serif text-xl text-white">
            {institution.name.charAt(0)}
          </div>
        )}
        <div>
          <h1 className="font-serif text-2xl font-semibold tracking-tight">{institution.name}</h1>
          {institution.tagline && (
            <p className="text-sm text-[#475569]">{institution.tagline}</p>
          )}
        </div>
      </header>

      <section className="mx-auto max-w-5xl px-6 py-14">
        {institution.about && (
          <p className="max-w-2xl font-serif text-lg leading-relaxed text-[#334155]">
            {institution.about}
          </p>
        )}

        {/* Signature element: role selection rendered as ID badges — the
            whole product is fundamentally "tell us who you are", so the
            login choice is styled after the physical object every member
            of a school already carries. */}
        <div className="mt-10 grid gap-6 sm:grid-cols-3">
          {ROLE_BADGES.map((badge) => {
            const label = badge.label ?? institution.roleLabels.guardian;
            return (
              <Link
                key={badge.role}
                href={`/login?role=${badge.role}`}
                className="group relative rounded-xl bg-white pt-6 shadow-sm ring-1 ring-black/5 transition hover:shadow-md"
              >
                {/* lanyard hole-punch */}
                <div className="absolute left-1/2 top-2 h-3 w-3 -translate-x-1/2 rounded-full bg-[#F7F5F0] ring-2 ring-inset ring-black/10" />
                <div className={`mx-4 rounded-t-lg ${badge.ribbon} px-4 py-3`}>
                  <p className="font-mono text-xs uppercase tracking-widest text-white/80">
                    Sign in as
                  </p>
                  <p className="font-serif text-xl font-semibold text-white">{label}</p>
                </div>
                <div className="px-4 py-4">
                  <p className="text-sm text-[#475569]">{badge.blurb}</p>
                  <p className="mt-3 text-sm font-medium text-[#1E2A4A] group-hover:underline">
                    Continue →
                  </p>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {institution.notices.length > 0 && (
        <section className="mx-auto max-w-5xl px-6 pb-16">
          <h2 className="font-mono text-xs uppercase tracking-widest text-[#475569]">
            Public notices
          </h2>
          <ul className="mt-3 divide-y divide-black/5 rounded-lg bg-white ring-1 ring-black/5">
            {institution.notices.map((n) => (
              <li key={n.id} className="flex items-center justify-between px-4 py-3">
                <span className="text-sm">{n.title}</span>
                <span className="font-mono text-xs text-[#94A3B8]">
                  {new Date(n.createdAt).toLocaleDateString()}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}
    </main>
  );
}

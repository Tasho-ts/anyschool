'use client';

// app/teacher/attendance/page.tsx
// Loads a class roster, lets the teacher tap through PRESENT/ABSENT/LATE/
// EXCUSED per student, then submits the whole day in one batched call —
// matching the upsert-friendly POST /teacher/attendance endpoint.

import { useEffect, useState } from 'react';
import { api } from '../lib/api';

type Status = 'PRESENT' | 'ABSENT' | 'LATE' | 'EXCUSED';
const STATUSES: Status[] = ['PRESENT', 'ABSENT', 'LATE', 'EXCUSED'];
const STATUS_STYLE: Record<Status, string> = {
  PRESENT: 'bg-[#2F855A] text-white',
  ABSENT: 'bg-[#C53030] text-white',
  LATE: 'bg-[#E8A33D] text-white',
  EXCUSED: 'bg-[#475569] text-white',
};

interface RosterStudent {
  id: string;
  rollNo: string;
  fullName: string;
  photoUrl: string | null;
}

export default function AttendanceMarking({ classId }: { classId: string }) {
  const today = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(today);
  const [roster, setRoster] = useState<RosterStudent[]>([]);
  const [statuses, setStatuses] = useState<Record<string, Status>>({});
  const [saving, setSaving] = useState(false);
  const [savedSummary, setSavedSummary] = useState<string | null>(null);

  useEffect(() => {
    api.get(`/admin/classes/${classId}/students`).then((students: RosterStudent[]) => {
      setRoster(students);
      // default everyone to PRESENT — the common case — so the teacher's
      // job is "mark the exceptions," not click every row.
      setStatuses(Object.fromEntries(students.map((s) => [s.id, 'PRESENT' as Status])));
    });
  }, [classId]);

  async function handleSubmit() {
    setSaving(true);
    setSavedSummary(null);
    try {
      const entries = roster.map((s) => ({ studentId: s.id, status: statuses[s.id] }));
      const res = await api.post('/teacher/attendance', { classId, date, entries });
      setSavedSummary(
        `Saved: ${res.summary.present} present · ${res.summary.absent} absent · ${res.summary.late} late · ${res.summary.excused} excused`,
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className="mx-auto max-w-2xl px-6 py-10">
      <div className="flex items-center justify-between">
        <h1 className="font-serif text-2xl font-semibold text-[#1E2A4A]">Mark attendance</h1>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="rounded-md border border-black/10 px-3 py-1.5 font-mono text-sm"
        />
      </div>

      <ul className="mt-6 divide-y divide-black/5 rounded-lg bg-white ring-1 ring-black/5">
        {roster.map((student) => (
          <li key={student.id} className="flex items-center justify-between gap-4 px-4 py-3">
            <div className="flex items-center gap-3">
              <span className="font-mono text-xs text-[#94A3B8]">{student.rollNo}</span>
              <span className="text-sm font-medium text-[#1E2A4A]">{student.fullName}</span>
            </div>
            <div className="flex gap-1.5">
              {STATUSES.map((status) => (
                <button
                  key={status}
                  onClick={() => setStatuses((s) => ({ ...s, [student.id]: status }))}
                  className={`rounded-full px-2.5 py-1 text-xs font-medium transition ${
                    statuses[student.id] === status ? STATUS_STYLE[status] : 'bg-[#F1F0EA] text-[#475569]'
                  }`}
                >
                  {status[0]}
                </button>
              ))}
            </div>
          </li>
        ))}
      </ul>

      <div className="mt-6 flex items-center gap-4">
        <button
          onClick={handleSubmit}
          disabled={saving || roster.length === 0}
          className="rounded-md bg-[#1E2A4A] px-4 py-2 font-medium text-white disabled:opacity-50"
        >
          {saving ? 'Saving…' : 'Save attendance'}
        </button>
        {savedSummary && <p className="text-sm text-[#475569]">{savedSummary}</p>}
      </div>
    </main>
  );
}

'use client';

// app/parent/page.tsx
// A guardian may have more than one linked child (see the `guardians` join
// table in schema.sql), so the whole dashboard is scoped to whichever
// child is currently selected.

import { useEffect, useState } from 'react';
import { api } from '../lib/api';

interface Child {
  id: string;
  fullName: string;
  className: string;
  photoUrl: string | null;
}

interface AttendanceSummary {
  percentage: number | null;
  present: number;
  total: number;
  records: { date: string; status: string }[];
}

interface GradeTrendPoint {
  term: string;
  subject: string;
  percentage: number;
}

export default function ParentDashboard() {
  const [children, setChildren] = useState<Child[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [attendance, setAttendance] = useState<AttendanceSummary | null>(null);
  const [grades, setGrades] = useState<GradeTrendPoint[]>([]);

  useEffect(() => {
    api.get('/parent/children').then((kids: Child[]) => {
      setChildren(kids);
      if (kids[0]) setSelectedId(kids[0].id);
    });
  }, []);

  useEffect(() => {
    if (!selectedId) return;
    const to = new Date().toISOString().slice(0, 10);
    const from = new Date(Date.now() - 30 * 86400_000).toISOString().slice(0, 10);
    api
      .get(`/parent/children/${selectedId}/attendance?from=${from}&to=${to}`)
      .then(setAttendance);
    api.get(`/parent/children/${selectedId}/grades`).then(setGrades);
  }, [selectedId]);

  const selectedChild = children.find((c) => c.id === selectedId);

  return (
    <main className="mx-auto max-w-2xl px-6 py-10">
      {/* Child switcher — only rendered when there's more than one, so a
          single-child family sees an uncluttered header instead. */}
      {children.length > 1 && (
        <div className="mb-6 flex gap-2">
          {children.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedId(c.id)}
              className={`rounded-full px-3 py-1.5 text-sm font-medium ${
                c.id === selectedId ? 'bg-[#1E2A4A] text-white' : 'bg-[#F1F0EA] text-[#475569]'
              }`}
            >
              {c.fullName.split(' ')[0]}
            </button>
          ))}
        </div>
      )}

      {selectedChild && (
        <h1 className="font-serif text-2xl font-semibold text-[#1E2A4A]">
          {selectedChild.fullName} <span className="text-base text-[#475569]">· {selectedChild.className}</span>
        </h1>
      )}

      <section className="mt-6 rounded-lg bg-white p-5 ring-1 ring-black/5">
        <h2 className="font-mono text-xs uppercase tracking-widest text-[#475569]">
          Attendance · last 30 days
        </h2>
        {attendance?.percentage != null ? (
          <div className="mt-2 flex items-baseline gap-2">
            <span className="font-serif text-4xl font-semibold text-[#1E2A4A]">
              {attendance.percentage}%
            </span>
            <span className="text-sm text-[#475569]">
              ({attendance.present} of {attendance.total} days)
            </span>
          </div>
        ) : (
          <p className="mt-2 text-sm text-[#475569]">No records yet.</p>
        )}

        {attendance && attendance.records.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-1">
            {attendance.records.map((r) => (
              <span
                key={r.date}
                title={`${r.date}: ${r.status}`}
                className={`h-4 w-4 rounded-sm ${
                  r.status === 'PRESENT'
                    ? 'bg-[#2F855A]'
                    : r.status === 'LATE'
                      ? 'bg-[#E8A33D]'
                      : r.status === 'EXCUSED'
                        ? 'bg-[#94A3B8]'
                        : 'bg-[#C53030]'
                }`}
              />
            ))}
          </div>
        )}
      </section>

      <section className="mt-6 rounded-lg bg-white p-5 ring-1 ring-black/5">
        <h2 className="font-mono text-xs uppercase tracking-widest text-[#475569]">
          Grades by subject
        </h2>
        <ul className="mt-3 space-y-2">
          {grades.map((g, i) => (
            <li key={i} className="flex items-center justify-between text-sm">
              <span className="text-[#1E2A4A]">
                {g.subject} <span className="text-[#94A3B8]">· {g.term}</span>
              </span>
              <span className="font-mono font-medium text-[#1E2A4A]">{g.percentage}%</span>
            </li>
          ))}
          {grades.length === 0 && <p className="text-sm text-[#475569]">No grades entered yet.</p>}
        </ul>
      </section>
    </main>
  );
}

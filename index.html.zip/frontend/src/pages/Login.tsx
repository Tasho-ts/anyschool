'use client';

// app/login/page.tsx — same page serves all four roles; the API decides
// what the identifier+password combination resolves to, this page just
// routes wherever the resulting token's role says to go.

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { api } from '../lib/api';

const ROLE_HOME: Record<string, string> = {
  INST_ADMIN: '/admin',
  TEACHER: '/teacher',
  GUARDIAN: '/parent',
  STUDENT: '/student',
};

export default function Login() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const roleHint = searchParams.get('role'); // from the badge the user clicked on the landing page

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [otpToken, setOtpToken] = useState<string | null>(null);
  const [otpCode, setOtpCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handlePasswordSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await api.post('/auth/login', { identifier, password });
      if (res.requiresOtp) {
        setOtpToken(res.otpToken); // switch the form into "enter the code we texted you" mode
      } else {
        completeLogin(res.accessToken, res.refreshToken, res.role);
      }
    } catch {
      setError('That email/phone or password looks wrong. Try again.');
    } finally {
      setLoading(false);
    }
  }

  async function handleOtpSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await api.post('/auth/otp/verify', { otpToken, code: otpCode });
      completeLogin(res.accessToken, res.refreshToken, res.role);
    } catch {
      setError("That code didn't match. Check the text message and try again.");
    } finally {
      setLoading(false);
    }
  }

  function completeLogin(accessToken: string, refreshToken: string, role: string) {
    // Access token lives in memory + a short-lived httpOnly cookie set by the
    // API response; refresh token is httpOnly-cookie only, never touched by
    // JS. (Storing tokens is omitted here — see lib/api.ts for the real
    // storage strategy.)
    api.setSession(accessToken, refreshToken);
    router.push(ROLE_HOME[role] ?? '/');
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-6">
      <h1 className="font-serif text-2xl font-semibold text-[#1E2A4A]">
        {roleHint ? `Sign in as ${roleHint.replace('_', ' ').toLowerCase()}` : 'Sign in'}
      </h1>

      {!otpToken ? (
        <form onSubmit={handlePasswordSubmit} className="mt-6 space-y-4">
          <div>
            <label className="text-sm text-[#475569]">Email or phone</label>
            <input
              className="mt-1 w-full rounded-md border border-black/10 px-3 py-2"
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              required
            />
          </div>
          <div>
            <label className="text-sm text-[#475569]">Password</label>
            <input
              type="password"
              className="mt-1 w-full rounded-md border border-black/10 px-3 py-2"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-md bg-[#1E2A4A] py-2 font-medium text-white disabled:opacity-50"
          >
            {loading ? 'Signing in…' : 'Sign in'}
          </button>
          <a href="/password/forgot" className="block text-center text-sm text-[#475569] underline">
            Forgot password?
          </a>
        </form>
      ) : (
        <form onSubmit={handleOtpSubmit} className="mt-6 space-y-4">
          <p className="text-sm text-[#475569]">Enter the code we texted you.</p>
          <input
            className="w-full rounded-md border border-black/10 px-3 py-2 text-center font-mono text-lg tracking-widest"
            value={otpCode}
            onChange={(e) => setOtpCode(e.target.value)}
            maxLength={6}
            required
          />
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-md bg-[#1E2A4A] py-2 font-medium text-white disabled:opacity-50"
          >
            {loading ? 'Verifying…' : 'Verify & sign in'}
          </button>
        </form>
      )}
    </main>
  );
}

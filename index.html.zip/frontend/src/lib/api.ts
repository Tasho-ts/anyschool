const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL ?? '/api/v1';

let accessToken: string | null = null;

async function request(method: string, path: string, body?: unknown) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
    },
    credentials: 'include', // sends the httpOnly refresh-token cookie
    body: body ? JSON.stringify(body) : undefined,
  });

  if (res.status === 401 && path !== '/auth/refresh') {
    // Access token expired — refresh once, then retry the original call.
    const refreshed = await request('POST', '/auth/refresh');
    accessToken = refreshed.accessToken;
    return request(method, path, body);
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.message ?? `Request failed: ${res.status}`);
  }
  return res.json();
}

export const api = {
  get: (path: string) => request('GET', path),
  post: (path: string, body?: unknown) => request('POST', path, body),
  setSession(access: string, refresh: string) {
    accessToken = access;
    // refreshToken itself is never stored in JS-reachable memory/localStorage —
    // the API response sets it as an httpOnly, Secure, SameSite=Lax cookie.
  },
};
